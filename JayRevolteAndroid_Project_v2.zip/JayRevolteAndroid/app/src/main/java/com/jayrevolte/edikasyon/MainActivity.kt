package com.jayrevolte.edikasyon

import android.media.MediaPlayer
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val Blue = Color(0xFF238BE6)
private val Yellow = Color(0xFFFFD54F)
private val Green = Color(0xFF53C878)
private val Orange = Color(0xFFFF9F43)
private val Purple = Color(0xFF9B72CF)
private val Red = Color(0xFFEF5350)
private val Ink = Color(0xFF263238)

data class LessonLetter(val upper: String, val lower: String, val word: String, val emoji: String)
data class ShapeLesson(val name: String, val detail: String, val example: String, val symbol: String)
data class ColorLesson(val name: String, val color: Color, val example: String)

private val letters = listOf(
    LessonLetter("A","a","Avyon","✈️"), LessonLetter("B","b","Boul","⚽"),
    LessonLetter("C","c","Chat","🐱"), LessonLetter("D","d","Dlo","💧"),
    LessonLetter("E","e","Elèv","🧒"), LessonLetter("F","f","Flè","🌸"),
    LessonLetter("G","g","Gato","🎂"), LessonLetter("H","h","Hamak","🛏️"),
    LessonLetter("I","i","Istwa","📖"), LessonLetter("J","j","Jaden","🌳"),
    LessonLetter("K","k","Kabrit","🐐"), LessonLetter("L","l","Liv","📚"),
    LessonLetter("M","m","Manman","👩"), LessonLetter("N","n","Nwa","⚫"),
    LessonLetter("O","o","Òdinatè","💻"), LessonLetter("P","p","Poul","🐔"),
    LessonLetter("Q","q","Qatar","🌍"), LessonLetter("R","r","Rad","👕"),
    LessonLetter("S","s","Solèy","☀️"), LessonLetter("T","t","Tab","🪑"),
    LessonLetter("U","u","Uit","8️⃣"), LessonLetter("V","v","Vè","🥛"),
    LessonLetter("W","w","Wou","🛞"), LessonLetter("X","x","Xilofòn","🎼"),
    LessonLetter("Y","y","Yoga","🧘"), LessonLetter("Z","z","Zèb","🌿")
)
private val numberWords = listOf("Zewo","Youn","De","Twa","Kat","Senk","Sis","Sèt","Uit","Nèf","Dis","Onz","Douz","Trèz","Katòz","Kenz","Sèz","Disèt","Dizuit","Diznèf","Ven")
private val shapes = listOf(
    ShapeLesson("Sèk","Yon fòm won ki pa gen kwen.","Tankou yon wou.","●"),
    ShapeLesson("Kare","Li gen kat kote ki menm longè.","Tankou yon mozayik kare.","■"),
    ShapeLesson("Rektang","Li gen kat kote ak de kote ki pi long.","Tankou yon pòt.","▰"),
    ShapeLesson("Triyang","Li gen twa kote ak twa kwen.","Tankou yon moso pitza.","▲"),
    ShapeLesson("Oval","Li won, men li pi long sou yon bò.","Tankou yon ze.","⬭"),
    ShapeLesson("Lozanj","Li gen kat kote ki menm longè.","Tankou yon kap vole.","◇")
)
private val colors = listOf(
    ColorLesson("Wouj", Color(0xFFE53935),"Tankou yon tomat."),
    ColorLesson("Ble", Color(0xFF2196F3),"Tankou syèl la."),
    ColorLesson("Jòn", Color(0xFFFFEB3B),"Tankou solèy la."),
    ColorLesson("Vèt", Color(0xFF43A047),"Tankou fèy pyebwa."),
    ColorLesson("Zoranj", Color(0xFFFF9800),"Tankou yon zoranj."),
    ColorLesson("Woz", Color(0xFFE91E63),"Tankou kèk flè."),
    ColorLesson("Mov", Color(0xFF8E24AA),"Tankou kèk rezen."),
    ColorLesson("Nwa", Color(0xFF212121),"Tankou koulè chabon."),
    ColorLesson("Blan", Color(0xFFFFFFFF),"Tankou lèt."),
    ColorLesson("Mawon", Color(0xFF795548),"Tankou tè."),
    ColorLesson("Gri", Color(0xFF9E9E9E),"Tankou kèk nwaj.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JayApp() }
    }
}

@Composable
fun JayApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("jay_revolte", 0) }
    var page by remember { mutableStateOf("lakay") }
    var selectedLetter by remember { mutableIntStateOf(0) }
    var selectedNumber by remember { mutableIntStateOf(0) }
    var selectedShape by remember { mutableIntStateOf(0) }
    var selectedColor by remember { mutableIntStateOf(0) }
    var score by remember { mutableIntStateOf(prefs.getInt("score", 0)) }
    var stars by remember { mutableIntStateOf(prefs.getInt("stars", 0)) }
    var completed by remember { mutableIntStateOf(prefs.getInt("completed", 0)) }
    var questionIndex by remember { mutableIntStateOf(0) }
    var feedback by remember { mutableStateOf("") }
    var gameScore by remember { mutableIntStateOf(0) }

    fun award(correct: Boolean) {
        if (correct) {
            score += 1; stars += 1
            prefs.edit().putInt("score", score).putInt("stars", stars).apply()
            feedback = "Bravo! Ou fè sa trè byen! ⭐"
        } else feedback = "Pa dekouraje! Eseye ankò!"
    }
    fun done() {
        completed += 1
        prefs.edit().putInt("completed", completed).apply()
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Blue, secondary = Orange, background = Color(0xFFF5FAFF))) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFFF5FAFF)) {
            Column(Modifier.fillMaxSize()) {
                if (page != "lakay") {
                    Row(Modifier.fillMaxWidth().background(Blue).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { page = "lakay"; feedback = "" }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Retounen", tint = Color.White)
                        }
                        Text(pageTitle(page), color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    }
                }
                when (page) {
                    "lakay" -> HomeScreen { page = it }
                    "alfabe" -> AlphabetScreen(selectedLetter, { selectedLetter = it }, { done() })
                    "konte" -> NumberScreen(selectedNumber, { selectedNumber = it }, { done() })
                    "fom" -> ShapeScreen(selectedShape, { selectedShape = it }, { done() })
                    "koule" -> ColorScreen(selectedColor, { selectedColor = it }, { done() })
                    "jwèt" -> GameScreen(questionIndex, { questionIndex = it }, feedback, { feedback = it }, gameScore, { gameScore = it }, ::award)
                    "pwogre" -> ProgressScreen(completed, score, stars)
                    "paran" -> ParentScreen()
                    else -> HomeScreen { page = it }
                }
            }
        }
    }
}

private fun pageTitle(page: String) = when(page) {
    "alfabe" -> "Ann aprann alfabè a"
    "konte" -> "Ann aprann konte"
    "fom" -> "Ann dekouvri fòm yo"
    "koule" -> "Ann aprann koulè yo"
    "jwèt" -> "Ann jwe pou n aprann"
    "pwogre" -> "Pwogrè mwen"
    else -> "Yon ti mesaj pou paran yo"
}

@Composable
fun HomeScreen(open: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("🌈", fontSize = 54.sp)
        Text("JAY REVOLTE", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Blue)
        Text("Byenveni nan Jay Revolte!", fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Ink)
        Text("Ann aprann pandan n ap pran plezi!", fontSize = 16.sp, color = Color.DarkGray, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        val options = listOf(
            Triple("Ann aprann alfabè a","🔤","alfabe"),
            Triple("Ann aprann konte","🔢","konte"),
            Triple("Ann dekouvri fòm yo","🔺","fom"),
            Triple("Ann aprann koulè yo","🎨","koule"),
            Triple("Ann jwe pou n aprann","🎮","jwèt"),
            Triple("Pwogrè mwen","🏆","pwogre"),
            Triple("Yon ti mesaj pou paran yo","💌","paran")
        )
        options.forEachIndexed { i, item ->
            val bg = listOf(Blue, Green, Purple, Orange, Red, Color(0xFF26A69A), Color(0xFF78909C))[i]
            Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { open(item.third) }, colors = CardDefaults.cardColors(containerColor = bg), shape = RoundedCornerShape(18.dp)) {
                Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(item.second, fontSize = 30.sp)
                    Spacer(Modifier.width(14.dp))
                    Text(item.first, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Spacer(Modifier.weight(1f))
                    Text("›", color = Color.White, fontSize = 30.sp)
                }
            }
        }
    }
}

@Composable
fun AudioButton(fileName: String, spokenText: String) {
    val context = LocalContext.current
    var message by remember { mutableStateOf("") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        FilledTonalButton(onClick = {
            val id = context.resources.getIdentifier(fileName, "raw", context.packageName)
            if (id == 0) message = "Vwa pwofesè a poko anrejistre."
            else {
                try {
                    player?.release()
                    player = MediaPlayer.create(context, id)
                    if (player != null) player?.start() else message = "Odyo a pa disponib."
                } catch (_: Exception) { message = "Odyo a pa kapab jwe kounye a." }
            }
        }) {
            Icon(Icons.Default.VolumeUp, contentDescription = "Koute")
            Spacer(Modifier.width(6.dp))
            Text("Koute pwofesè a")
        }
        if (message.isNotBlank()) Text(message, fontSize = 12.sp, color = Color.DarkGray)
    }
}

@Composable
fun AlphabetScreen(index: Int, select: (Int) -> Unit, complete: () -> Unit) {
    val item = letters[index]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Chwazi yon lèt pou aprann li.", fontSize = 17.sp)
        LazyVerticalGrid(columns = GridCells.Fixed(6), modifier = Modifier.fillMaxWidth().height(210.dp), userScrollEnabled = false) {
            items(letters.indices.toList()) { i ->
                Box(Modifier.padding(3.dp).clip(RoundedCornerShape(10.dp)).background(if (i == index) Yellow else Color.White).clickable { select(i) }.padding(8.dp), contentAlignment = Alignment.Center) {
                    Text(letters[i].upper, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("${item.upper} ${item.lower}", fontSize = 76.sp, fontWeight = FontWeight.Black, color = Blue)
        Text(item.emoji, fontSize = 76.sp)
        Text(item.word, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(" ${item.upper} se premye lèt nan mo ${item.word}.", textAlign = TextAlign.Center, fontSize = 18.sp)
        AudioButton("le_${item.lower}", "${item.upper} tankou ${item.word}")
        Button(onClick = complete) { Text("Mwen fini leson sa a") }
    }
}

@Composable
fun NumberScreen(index: Int, select: (Int) -> Unit, complete: () -> Unit) {
    val n = index
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Chwazi yon nimewo.", fontSize = 18.sp)
        LazyVerticalGrid(columns = GridCells.Fixed(5), modifier = Modifier.fillMaxWidth().height(210.dp), userScrollEnabled = false) {
            items((0..20).toList()) { v ->
                Box(Modifier.padding(4.dp).clip(RoundedCornerShape(10.dp)).background(if (v == n) Yellow else Color.White).clickable { select(v) }.padding(10.dp), contentAlignment = Alignment.Center) {
                    Text(v.toString(), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Text(n.toString(), fontSize = 80.sp, fontWeight = FontWeight.Black, color = Blue)
        Text(numberWords[n], fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(if (n == 0) "Pa gen okenn objè." else (1..n).joinToString(" ") { "🍎" }, fontSize = 30.sp, textAlign = TextAlign.Center)
        Text("Ann konte ansanm: ${if (n == 0) "zewo" else (1..n).joinToString(", ") { numberWords[it].lowercase() }}", textAlign = TextAlign.Center)
        AudioButton("chif_$n", numberWords[n])
        Button(onClick = complete) { Text("Mwen fini leson sa a") }
    }
}

@Composable
fun ShapeScreen(index: Int, select: (Int) -> Unit, complete: () -> Unit) {
    val item = shapes[index]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Chwazi yon fòm.", fontSize = 18.sp)
        shapes.forEachIndexed { i, s ->
            FilterChip(selected = index == i, onClick = { select(i) }, label = { Text(s.name) })
        }
        Text(item.symbol, fontSize = 110.sp, color = Purple)
        Text(item.name, fontSize = 30.sp, fontWeight = FontWeight.Bold)
        Text(item.detail, fontSize = 18.sp, textAlign = TextAlign.Center)
        Text(item.example, fontSize = 17.sp)
        AudioButton("fom_$index", item.name)
        Button(onClick = complete) { Text("Mwen fini leson sa a") }
    }
}

@Composable
fun ColorScreen(index: Int, select: (Int) -> Unit, complete: () -> Unit) {
    val item = colors[index]
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Chwazi yon koulè.", fontSize = 18.sp)
        LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.fillMaxWidth().height(180.dp), userScrollEnabled = false) {
            items(colors.indices.toList()) { i ->
                Box(Modifier.padding(5.dp).size(58.dp).clip(CircleShape).background(colors[i].color).clickable { select(i) })
            }
        }
        Box(Modifier.size(150.dp).clip(CircleShape).background(item.color))
        Text(item.name, fontSize = 32.sp, fontWeight = FontWeight.Bold)
        Text(item.example, fontSize = 18.sp)
        AudioButton("koule_$index", item.name)
        Button(onClick = complete) { Text("Mwen fini leson sa a") }
    }
}

@Composable
fun GameScreen(q: Int, setQ: (Int) -> Unit, feedback: String, setFeedback: (String) -> Unit, points: Int, setPoints: (Int) -> Unit, answer: (Boolean) -> Unit) {
    val prompts = listOf(
        Triple("Ki premye lèt mo CHAT la?","C", listOf("A","C","T")),
        Triple("Konbyen pòm ou wè? 🍎 🍎 🍎","3", listOf("2","3","4")),
        Triple("Ki koulè solèy la?","Jòn", listOf("Ble","Jòn","Vèt")),
        Triple("Ki fòm ki gen twa kote?","Triyang", listOf("Sèk","Kare","Triyang")),
        Triple("Ki nimewo ki vini apre 4?","5", listOf("3","5","7"))
    )
    val p = prompts[q % prompts.size]
    Column(Modifier.fillMaxSize().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Kesyon ${q % prompts.size + 1} sou ${prompts.size}", color = Blue, fontWeight = FontWeight.Bold)
        Text(p.first, fontSize = 25.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        p.third.forEach { choice ->
            Button(onClick = {
                val good = choice == p.second
                answer(good)
                if (good) { setPoints(points + 1); setQ(q + 1) }
            }, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Text(choice, fontSize = 20.sp) }
        }
        Text(feedback, fontSize = 18.sp, textAlign = TextAlign.Center)
        Text("Pwen nan jwèt sa a: $points", fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ProgressScreen(completed: Int, score: Int, stars: Int) {
    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("🏆", fontSize = 80.sp)
        Text("Gade jan w ap pwogrese!", fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        StatCard("Leson fini", completed.toString(), Blue)
        StatCard("Bon repons", score.toString(), Green)
        StatCard("Zetwal mwen", "⭐ $stars", Orange)
    }
}

@Composable
fun StatCard(label: String, value: String, color: Color) {
    Card(Modifier.fillMaxWidth().padding(7.dp), colors = CardDefaults.cardColors(containerColor = color)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun ParentScreen() {
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("💌", fontSize = 65.sp)
        Text("Yon ti mesaj pou paran yo", fontSize = 23.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(18.dp))
        Text(
            "Avèk anpil lanmou pou papa Christopher ak manman Blondine.\n\n" +
            "Nou swete tout konesans timoun nan aprann nan aplikasyon Jay Revolte la ede l grandi, devlope entèlijans li epi prepare yon bèl avni pou li.\n\n" +
            "Aprann se yon bèl avanti. Kontinye ankouraje l chak jou!",
            fontSize = 19.sp, lineHeight = 29.sp, textAlign = TextAlign.Center
        )
    }
}
