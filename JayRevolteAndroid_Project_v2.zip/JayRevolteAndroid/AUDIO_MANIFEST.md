# Lis anrejistreman vwa pou JAY REVOLTE

Tout fraz yo dwe anrejistre ak yon vwa gason ki pale Kreyòl Ayisyen, dousman, klè, epi avèk pasyans.

## Fraz jeneral
- Bonjou timoun! Jodi a, ann aprann ansanm.
- Bravo! Ou fè sa trè byen!
- Pa dekouraje! Eseye ankò!
- Ann konte ansanm.

## Non dosye
Lèt: `le_a.mp3` rive `le_z.mp3`
Chif: `chif_0.mp3` rive `chif_20.mp3`
Fòm: `fom_0.mp3` rive `fom_5.mp3`
Koulè: `koule_0.mp3` rive `koule_10.mp3`

Anrejistre non ak egzanp chak leson. Kenbe chak fichye kout, pwòp, epi san bri dèyè.
