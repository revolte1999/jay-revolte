# JAY REVOLTE — pwojè Android

Aplikasyon edikatif natif pou Android, ekri an Kotlin ak Jetpack Compose. Pwojè a gen:
- Alfabè A–Z, nimewo 0–20, fòm ak koulè.
- Senk kalite kesyon jwèt.
- Pwen, zetwal ak leson fini ki rete anrejistre lokalman.
- Estrikti pou jwe anrejistreman odyo lokal yo.
- Pa gen kont, enskripsyon oswa pèmisyon entènèt.

## Sa ki poko pare
Pa gen anrejistreman vwa gason an nan pwojè sa a. Bouton odyo yo chèche fichye lokal ki gen non yo bay anba a; si fichye a poko ajoute, aplikasyon an di klèman: "Vwa pwofesè a poko anrejistre." Sa vle di odyo pa dwe prezante kòm fonksyonèl jiskaske fichye MP3 yo mete epi teste.

## Ajoute anrejistreman yo
Kreye dosye `app/src/main/res/raw/` epi mete MP3 yo ladan:
- `le_a.mp3` ... `le_z.mp3`
- `chif_0.mp3` ... `chif_20.mp3`
- `fom_0.mp3` ... `fom_5.mp3`
- `koule_0.mp3` ... `koule_10.mp3`

Non fichye yo dwe an miniskil, san espas, san aksan. Chak anrejistreman dwe pale Kreyòl Ayisyen natirèlman. Pou kounye a aplikasyon an pa itilize TTS kòm ranplasman, paske sa pa garanti bon pwononsyasyon Kreyòl.

## Louvri epi konpile
1. Enstale Android Studio sou yon òdinatè.
2. Louvri katab `JayRevolteAndroid` nan Android Studio.
3. Kite Gradle senkronize epi telechaje depandans yo.
4. Chwazi **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Lè Android Studio fini, chwazi lyen APK a nan notifikasyon rezilta a.
6. Pou pataje ak enstale kòm aplikasyon nòmal, sèvi ak yon APK siyen: **Build > Generate Signed Bundle / APK**.

## Kondisyon devlopman
- Android Studio ak Android SDK Platform 35.
- JDK 17 oswa pi resan.
- Gradle wrapper ka ajoute otomatikman nan Android Studio lè pwojè a ouvri.

## Nòt tès
Nan anviwònman kote pwojè sa a te prepare a, Android SDK/Gradle pa disponib. Se poutèt sa APK a pa te konpile, enstale oswa teste sou yon aparèy reyèl. Tès manyèl sou aparèy Android obligatwa anvan piblikasyon.


## Konpile APK otomatikman sou GitHub (san òdinatè)
Pwojè a gen yon workflow GitHub Actions nan `.github/workflows/build-apk.yml`.
1. Kreye yon nouvo depo (repository) sou GitHub.
2. Telechaje/dekonprese ZIP pwojè a, epi mete tout fichye yo nan depo a sou branch `main`.
3. Nan depo a, ouvri onglet **Actions**.
4. Chwazi **Konpile APK JAY REVOLTE**, epi peze **Run workflow** (oswa tann li lanse apre push).
5. Lè travay la fini ak yon mak vèt, ouvri rezilta a epi telechaje fichye **Jay-Revolte-APK-debug** nan seksyon Artifacts.
6. Debloke APK a sou telefòn Android la epi enstale li. Android ka mande otorizasyon pou enstale aplikasyon ki soti nan sous sa a.

Nòt: APK debug la fèt pou tès. Pou distribisyon piblik oswa itilizasyon alontèm, jenere yon APK release ki siyen ak yon kle prive ou konsève an sekirite. Pa pataje kle siyen an.
