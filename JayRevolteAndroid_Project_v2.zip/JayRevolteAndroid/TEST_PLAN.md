# Plan tès anvan lage

- [ ] Louvri aplikasyon an sou Android 6 oswa pi resan.
- [ ] Verifye chak bouton sou paj dakèy la.
- [ ] Verifye 26 lèt yo youn apre lòt.
- [ ] Verifye nimewo 0 rive 20 ak kantite objè yo.
- [ ] Verifye 6 fòm yo ak eksplikasyon yo.
- [ ] Verifye 11 koulè yo.
- [ ] Verifye bon ak move repons nan jwèt la.
- [ ] Verifye pwen, zetwal ak pwogrè apre fèmen/relouvri aplikasyon an.
- [ ] Mete fichye odyo yo epi verifye chak bouton odyo.
- [ ] Mete telefòn nan sou mòd avyon epi verifye tout leson yo.
- [ ] Jenere APK siyen, enstale li sou yon aparèy Android reyèl.
